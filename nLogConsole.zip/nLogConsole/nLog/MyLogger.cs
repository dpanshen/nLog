﻿using System;
using NLog;
using NLog.Config;
using NLog.Targets;
using Elastic.CommonSchema.NLog;
using System.Globalization;

namespace nLog
{
    class Company
    {
        public string Name { get; set; }
        public string Address { get; set; }
    }
    class Department
    {
        public string Name { get; set; }
        public int Members { get; set; }
    }
    class Employee
    {
        public string Name { get; set; }
        public string Department { get; set; }
    }

    public class MyLogger
    {
        string _filename;
        FileTarget _fileTarget;
        LoggingConfiguration _config;
        const string _medata = "customData";
        const string _empty = "empty";

        #region - variables for testing overloading
        CultureInfo culInfo = System.Globalization.CultureInfo.CurrentCulture;
        byte b = 1;
        ulong ul = 100;
        uint ui = 1;
        sbyte sb = 1;
        decimal d = 1.2m;
        float f = 1.2f;
        Company cpy = new Company() { Name = "MyUS", Address = "100 Main street" };
        Department dept = new Department() { Name = "IT", Members = 30 };
        Employee emp = new Employee() { Name = "John", Department = "IT" };
        object[] objArgs = new object[3];
        #endregion

        public MyLogger(string fileName)
        {
            _filename = fileName;
            objArgs[0] = cpy;
            objArgs[1] = dept;
            objArgs[2] = emp;
        }

        private Logger GetCurrentLogger()
        {
            if (_config == null)
                _config = new LoggingConfiguration();

            if (_fileTarget == null)
            {
                _fileTarget = new FileTarget()
                {
                    Layout = new EcsLayout(),
                    FileName = _filename,
                    ConcurrentWrites = true,
                    NetworkWrites = true
                };
            }
            _config.AddRuleForAllLevels(_fileTarget);

            LogManager.Configuration = _config;
            Logger logger = LogManager.GetCurrentClassLogger();

            return logger;
        }

        private void TestLogWithMetaData(LogLevel logLevel, Exception exception, string message, Logger logger, params object[] objects)
        {
            var msg = new LogEventInfo(logLevel, message, culInfo, message, objects, exception);
            msg.Properties.Add("metadata", objects);
            logger.Log(msg);
        }

        #region Methods for client calls
        private LogEventInfo GetLogEventInfo(LogLevel loglevel, string message, params object[] metadata)
        {
            LogEventInfo eventInfo = new LogEventInfo(loglevel, message, culInfo, message, metadata);
            eventInfo.Properties.Add(_medata, metadata);
            return eventInfo;
        }
        private LogEventInfo GetLogEventInfo(LogLevel loglevel, string message, Exception exception, params object[] metadata)
        {
            LogEventInfo eventInfo = new LogEventInfo(loglevel, message, culInfo, message, metadata, exception);
            eventInfo.Properties.Add(_medata, metadata);
            return eventInfo;
        }
        public void Log(LogLevel loglevel, string message)
        {
            Log(loglevel, message, _empty);
        }
        public void Log(LogLevel loglevel, string message, params object[] metadata)
        {
            var eventInfo = GetLogEventInfo(loglevel, message, metadata);

            if (loglevel == NLog.LogLevel.Trace)
                GetCurrentLogger().Trace(eventInfo);
            else if (loglevel == NLog.LogLevel.Debug)
                GetCurrentLogger().Debug(eventInfo);
            else if (loglevel == NLog.LogLevel.Info)
                GetCurrentLogger().Info(eventInfo);
            else if (loglevel == NLog.LogLevel.Warn)
                GetCurrentLogger().Warn(eventInfo);
            else if (loglevel == NLog.LogLevel.Error)
                GetCurrentLogger().Error(eventInfo);
            else if (loglevel == NLog.LogLevel.Fatal)
                GetCurrentLogger().Fatal(eventInfo);
        }

        public void Log(LogLevel loglevel, Exception exception,  string message)
        {
            Log(loglevel, exception, message, _empty);
        }

        public void Log(LogLevel loglevel, Exception exception, string message, params object[] metadata)
        {
            var eventInfo = GetLogEventInfo(loglevel, message, exception, metadata);

            if (loglevel == NLog.LogLevel.Trace)
                GetCurrentLogger().Trace(eventInfo);
            else if (loglevel == NLog.LogLevel.Debug)
                GetCurrentLogger().Debug(eventInfo);
            else if (loglevel == NLog.LogLevel.Info)
                GetCurrentLogger().Info(eventInfo);
            else if (loglevel == NLog.LogLevel.Warn)
                GetCurrentLogger().Warn(eventInfo);
            else if (loglevel == NLog.LogLevel.Error)
                GetCurrentLogger().Error(eventInfo);
            else if (loglevel == NLog.LogLevel.Fatal)
                GetCurrentLogger().Fatal(eventInfo);

        }
        public void Trace(string message)
        {
            Trace(message, _empty);
        }
        public void Trace(string message, params object[] metadata)
        {
            var eventInfo = GetLogEventInfo(LogLevel.Trace, message, metadata);
            GetCurrentLogger().Trace(eventInfo);
        }
        public void Trace(Exception exception, string message)
        {
            Trace(exception, message, _empty);
        }
        public void Trace(Exception exception, string message, params object[] metadata)
        {
            var eventInfo = GetLogEventInfo(LogLevel.Trace, message, exception, metadata);
            GetCurrentLogger().Trace(eventInfo);
        }

        public void Debug(string message)
        {
            Debug(message, _empty);
        }
        public void Debug(string message, params object[] metadata)
        {
            var eventInfo = GetLogEventInfo(LogLevel.Debug, message, metadata);
            GetCurrentLogger().Debug(eventInfo);
        }
        public void Debug(Exception exception, string message)
        {
            Debug(exception, message, _empty);
        }
        public void Debug(Exception exception, string message, params object[] metadata)
        {
            var eventInfo = GetLogEventInfo(LogLevel.Debug, message, exception, metadata);
            GetCurrentLogger().Debug(eventInfo);
        }

        public void Info(string message)
        {
            Info(message, _empty);
        }
        public void Info(string message, params object[] metadata)
        {
            var eventInfo = GetLogEventInfo(LogLevel.Info, message, metadata);
            GetCurrentLogger().Info(eventInfo);
        }
        public void Info(Exception exception, string message)
        {
            Info(exception, message, _empty);
        }
        public void Info(Exception exception, string message, params object[] metadata)
        {
            var eventInfo = GetLogEventInfo(LogLevel.Info, message, exception, metadata);
            GetCurrentLogger().Info(eventInfo);
        }

        public void Warn(string message)
        {
            Warn(message, _empty);
        }
        public void Warn(string message, params  object[] metadata)
        {
            var eventInfo = GetLogEventInfo(LogLevel.Warn, message, metadata);
            GetCurrentLogger().Warn(eventInfo);
        }
        public void Warn(Exception exception, string message)
        {
            Warn(exception, message, _empty);
        }
        public void Warn(Exception exception, string message, params object[] metadata)
        {
            var eventInfo = GetLogEventInfo(LogLevel.Warn, message, exception, metadata);
            GetCurrentLogger().Warn(eventInfo);
        }

        public void Error(string message)
        {
            Error(message, _empty);
        }
        public void Error(string message, params object[] metadata)
        {
            var eventInfo = GetLogEventInfo(LogLevel.Error, message, metadata);
            GetCurrentLogger().Error(eventInfo);
        }
        public void Error(Exception exception, string message)
        {
            Error(exception, message, _empty);
        }
        public void Error(Exception exception, string message, params object[] metadata)
        {
            var eventInfo = GetLogEventInfo(LogLevel.Error, message, exception, metadata);
            GetCurrentLogger().Error(eventInfo);
        }

        public void Fatal(string message)
        {
            Fatal(message, _empty);
        }
        public void Fatal(string message, params object[] metadata)
        {
            var eventInfo = GetLogEventInfo(LogLevel.Fatal, message, metadata);
            GetCurrentLogger().Fatal(eventInfo);
        }
        public void Fatal(Exception exception, string message)
        {
            Fatal(exception, message, _empty);
        }
        public void Fatal(Exception exception, string message, params object[] metadata)
        {
            var eventInfo = GetLogEventInfo(LogLevel.Fatal, message, exception, metadata);
            GetCurrentLogger().Fatal(eventInfo);
        }
        #endregion
    }
}
