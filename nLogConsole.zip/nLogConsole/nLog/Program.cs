﻿using Newtonsoft.Json;
using NLog;
using System;
using System.Collections.Generic;

namespace nLog
{
    class Student
    {
        public string Name { get; set; }
        public string Major { get; set; }
    }
    class Program
    {
        static bool TestLogs(string fileName)
        {
            MyLogger myLogger = new MyLogger(fileName);
            bool result = false;
            List<string> NUMs = new List<string>() { "One", "Two", "Three" };

            try
            {
                int a = 1, b = 0;
                int c = a / b;
            }
            catch (Exception exp)
            {
                myLogger.Log(LogLevel.Trace, "Test Log.Trace: string");
                myLogger.Log(LogLevel.Debug, "Test Log.Debug: string");
                myLogger.Log(LogLevel.Info, "Test Log.Info: string");
                myLogger.Log(LogLevel.Warn, "Test Log.Warn: string");
                myLogger.Log(LogLevel.Error, "Test Log.Error: string");
                myLogger.Log(LogLevel.Fatal, "Test Log.Fatal: string");

                myLogger.Log(LogLevel.Trace, exp, "Test Log.Trace: string, Exception");
                myLogger.Log(LogLevel.Debug, exp, "Test Log.Debug: string, Exception");
                myLogger.Log(LogLevel.Info, exp, "Test Log.Info: string, Exception"); ;
                myLogger.Log(LogLevel.Warn, exp, "Test Log.Warn: string, Exception");
                myLogger.Log(LogLevel.Error, exp, "Test Log.Error: string, Exception");
                myLogger.Log(LogLevel.Fatal, exp, "Test Log.Fatal: string, Exception");

                myLogger.Log(LogLevel.Trace, exp, "Test Log.Trace: string, Exception, metadata", "notes", 1, true, 10.9m, JsonConvert.SerializeObject(new Student() { Name = "John", Major = "Finance" }));
                myLogger.Log(LogLevel.Debug, exp, "Test Log.Debug: string, Exception, metadata", "notes", 1, true, 10.9m, new { Name = "Kim", Address = "100 main st" });
                myLogger.Log(LogLevel.Info, exp, "Test Log.Info: string, Exception, metadata", "notes", 1, true, 10.9m, NUMs);
                myLogger.Log(LogLevel.Warn, exp, "Test Log.Warn: string, Exception, metadata", "notes");
                myLogger.Log(LogLevel.Error, exp, "Test Log.Error: string, Exception, metadata", "Weeks");
                myLogger.Log(LogLevel.Fatal, exp, "Test Log.Fatal: string, Exception, metadata", "Days");

                myLogger.Trace("Test Trace: string");
                myLogger.Trace("Test Trace: string, medatata", 1, 10.1m, new Student() { Name = "Kim", Major = "Accounting" });
                myLogger.Trace(exp, "Test Trace: Exception, string");
                myLogger.Trace(exp, "Test Trace: Exception, string, metadata", new { Name = "Testing Trace w Metatata", Id = 1 });

                myLogger.Debug("Test Debug: string");
                myLogger.Debug("Test Debug: string, medatata", 1, new { Name = "FOO", num = 10 });
                myLogger.Debug(exp, "Test Debug: Exception, string");
                myLogger.Debug(exp, "Test Debug: Exception, string, metadata", new { Name = "Testing Trace w Metatata", Id = 1 });

                myLogger.Info("Test Info: string");
                myLogger.Info("Test Info: string, metadata", 1, true);
                myLogger.Info(exp, "Test Info: Exception, string");
                myLogger.Info(exp, "Test Info: Exception, string, metadata", new { Name = "Testing Trace w Metatata", Id = 1 }, "notes:  added an lement to medata array");

                myLogger.Warn("Test Warn: string");
                myLogger.Warn("Test Warn, string, metadata", 1, new { Id = 12, Tag = "Warn" });
                myLogger.Warn(exp, "Test Warn: Exception, string");
                myLogger.Warn(exp, "Test Warn: Exception, string, metadata", new { Name = "Testing Trace w Metatata", Id = 1 }, new Student() { Name = "John", Major = "English" });

                myLogger.Error("Test Error: string");
                myLogger.Error("Test Error: string, metadata", 1, true);
                myLogger.Error(exp, "Test Error: Exception, string");
                myLogger.Error(exp, "Test Error: Exception, string, metadata", new { Name = "Testing Error w Metatata", Id = 1 }, new Student() { Name = "John", Major = "English" }, 10.89m);

                myLogger.Fatal("Test Fatal: string");
                myLogger.Fatal("Test Fatal: string, metadata", 10, "test");
                myLogger.Fatal(exp, "Test Fatal: Exception, string");
                myLogger.Fatal(exp, "Test Fatal: Exception, string, metadata", new { Name = "Testing Fatal w Metatata", Id = 1 }, new Student() { Name = "John", Major = "English" }, 10.89m, 100);

                result = true;
            }

            return result;

        }

        static void Main(string[] args)
        {
            Console.WriteLine("Start testing logs:");

            string fileName = String.Format("{0}\\nLog\\Console_{1}.json",
                           Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                           DateTime.Now.ToString("yyyy-MM-dd"));

            bool result = TestLogs(fileName);
            if (result)
                Console.WriteLine("\nLogs have been tested for all log levels. Please see latest logs in file {0}", fileName);
            else
                Console.WriteLine("\nFailed to test for all levels.");

            Console.WriteLine("\nEnter a key to end the program");
            Console.ReadLine();
        }
    }
}
